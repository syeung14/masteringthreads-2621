#---
# Excerpted from "Programming Concurrency on the JVM",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/vspcon for more book information.
#---
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 1
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 2
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 3
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 4
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 5
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 6
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 7
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 8
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 9
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 10
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 11
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 12
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 13
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 14
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 15
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 16
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 17
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 18
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 19
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 20
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 21
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 22
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 23
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 24
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 25
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 26
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 27
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 28
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 29
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 30
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 31
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 32
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 33
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 34
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 35
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 36
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 37
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 38
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 39
java com.agiledeveloper.pcj.ConcurrentNAVVaryThread 40
