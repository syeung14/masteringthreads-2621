package com.agiledeveloper.pcj

class AccountOperationFailedException extends RuntimeException {
}
